#pragma once

#ifdef LISTA_POS_INT_IMP

#include <iostream>
using namespace std;
#include <assert.h>

#endif
