#include "Ejercicios.h"

int contadorPilas(PilaInt p, int dato) {
	int contador = 0;
	PilaInt p1 = clon(p);
	while (!esVacia(p1)) {
		if (top(p1) == dato) {
			contador++;
		}
		pop(p1);
	}
	return contador;
}

ListaOrdInt EnlistarAux(ListaOrdInt lista, NodoABInt* a) {
	if (a == NULL) {
		return NULL;
	}
	EnlistarAux(lista, a->izq);
	agregar(lista, a->dato); // agrego el dato
	EnlistarAux(lista, a->der);
	return lista;
}

ListaOrdInt Enlistar(NodoABInt* a)
{
	if (a != NULL) {
		ListaOrdInt lista = crearListaOrdInt(); // creo la lista
		lista = EnlistarAux(lista, a);
		return lista;
	}
	return NULL;
}

ListaOrdInt UnionListaOrd(ListaOrdInt l1, ListaOrdInt l2)
{
	ListaOrdInt final = crearListaOrdInt();
	ListaOrdInt clonL1 = clon(l1);
	ListaOrdInt clonL2 = clon(l2);

	while (!esVacia(clonL1)) {
		agregar(final, minimo(clonL1));
		borrarMinimo(clonL1);
	}
	while (!esVacia(clonL2)) {
		agregar(final, minimo(clonL2));
		borrarMinimo(clonL2);
	}

	return final;
}

bool EstaContenida(PilaInt p1, PilaInt p2)
{
	if (esVacia(p1)) {
		return true;
	}
	else if (esVacia(p2)) {
		return false;
	}

	PilaInt clonP1 = clon(p1);
	PilaInt clonP2 = clon(p2);
	while (!esVacia(clonP1)) {
		int contP1 = contadorPilas(clonP1, top(clonP1));
		int contP2 = contadorPilas(clonP2, top(clonP1));	

		if (contP1 > contP2) {
			return false;
		}
		pop(clonP1);
	}
	return true;
}

ListaOrdInt ObtenerRepetidos(MultisetInt m) 
{
	//IMPLEMENTAR SOLUCION
	return NULL;
}

MultisetInt Xor(MultisetInt m1, MultisetInt m2)
{
	//IMPLEMENTAR SOLUCION
	return NULL;
}

ColaPrioridadInt MenorPrioridad(ColaPrioridadInt c) {
	//IMPLEMENTAR SOLUCION
	return NULL;
}

