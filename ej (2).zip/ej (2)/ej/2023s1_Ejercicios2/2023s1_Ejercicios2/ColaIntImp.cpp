#include "ColaInt.h"

#ifdef COLA_INT_IMP

struct _cabezalColaInt {
	NodoListaInt* primero;
	NodoListaInt* ultimo;
	int cantidad;
};

ColaInt crearColaInt() {
	ColaInt cola = new _cabezalColaInt;
	cola->primero = NULL;
	cola->ultimo = NULL;
	cola->cantidad = 0;
	return cola;
}

void encolar(ColaInt& c, int e) {
	NodoListaInt* agregar = new NodoListaInt;
	agregar->dato = e;
	agregar->sig = NULL;
	if (c->primero == NULL) {
		c->primero = agregar;
	}
	else {
		c->ultimo->sig = agregar;
	}
	c->ultimo = agregar;
	c->cantidad++;
}

int principio(ColaInt c) {
	if (!esVacia(c)) {
		return c->primero->dato;
	}
}

void desencolar(ColaInt& c) {
	assert(c->primero != NULL);
	NodoListaInt* aBorrar = c->primero;
	c->primero = c->primero->sig;
	if (c->primero == NULL) c->ultimo = NULL;
	delete aBorrar;
	c->cantidad--;
}

bool esVacia(ColaInt c) {
	return c->primero == NULL;
}

unsigned int cantidadElementos(ColaInt c) {
	return c->cantidad;
}

ColaInt clon(ColaInt c) {
	ColaInt clonada = crearColaInt();
	clonada->cantidad = c->cantidad;

	NodoListaInt* aux = c->primero;
	NodoListaInt* primeroNuevo = NULL;
	NodoListaInt* ultimo = primeroNuevo;

	while (aux != NULL) {
		NodoListaInt* q = new NodoListaInt;
		q->dato = aux->dato;
		q->sig = aux->sig;
		if (primeroNuevo == NULL) {
			primeroNuevo = q;
			ultimo = q;
		}
		else {
			ultimo->sig = q;
			ultimo = q;
		}
		aux = aux->sig;
	}
	clonada->ultimo = ultimo;
	clonada->primero = primeroNuevo;

	return clonada;
}

void destruir(ColaInt& c) {
	while (!esVacia(c)) {
		desencolar(c);
	}
	delete c;
}

#endif