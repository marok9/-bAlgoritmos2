#pragma once

#include "FuncAux.h"
#include "Defensa.h"
#include "FuncAuxTAD.h"

/*
//Mat
void pruebaInterseccionLista(const char* inputList1, const char* inputList2);
void pruebaExcluidos(const char* inputList1, const char* inputList2, const char* inputList3);
void pruebaListarHojas(const char* inputTree);

//Noct
void pruebaEstanContenidos(const char* inputList1, const char* inputList2);
void pruebaMerge(const char* inputCP1elem, const char* inputCP1prio, const char* inputCP2elem, const char* inputCP2prio);
void pruebaListarHojasPorNiveles(const char* inputTree);

*/
