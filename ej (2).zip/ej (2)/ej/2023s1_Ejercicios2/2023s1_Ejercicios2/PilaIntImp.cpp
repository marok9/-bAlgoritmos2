#include "PilaInt.h"

#ifdef PILA_INT_IMP

struct _cabezalPilaInt { 
	// Esto contiene la lista de las pilas y la cantidad de elementos.
	int cantidad;
	NodoListaInt* lista;
};

PilaInt crearPilaInt(){
	PilaInt p = new _cabezalPilaInt;
	p->lista = NULL;
	p->cantidad = 0;
	return p;
}

void push(PilaInt& p, int e) {
	NodoListaInt* aux = new NodoListaInt;
	aux->dato = e;
	aux->sig = p->lista;
	p->lista = aux;
	p->cantidad++;
}

int top(PilaInt p) {
	if (!esVacia(p)) {
		return p->lista->dato;
	}
	return NULL;
}

void pop(PilaInt& p) {
	if (!esVacia(p)) {
		NodoListaInt* aux = new NodoListaInt;
		aux = p->lista;
		p->lista = p->lista->sig;
		delete aux;
		p->cantidad--;
	}
}

unsigned int cantidadElementos(PilaInt p) {
	return p->cantidad;
}

bool esVacia(PilaInt p) {
	if (p->cantidad == 0) {
		return true;
	}
	else {
		return false;
	}
}

PilaInt clon(PilaInt p) {	
	
	int nuevaCant = p->cantidad;
	NodoListaInt* nueva = NULL;
	NodoListaInt* pun = nueva;
	NodoListaInt* aux = p->lista;
	while (aux != NULL) {
		NodoListaInt* q = new NodoListaInt;
		q->dato = aux->dato;
		q->sig = NULL;
		if (nueva == NULL) {
			nueva = q;
			pun = nueva;
		}
		else {
			pun->sig = q;
			pun = pun->sig;
		}
		aux = aux->sig;
	}
	PilaInt clonada = crearPilaInt();
	clonada->cantidad = nuevaCant;
	clonada->lista = nueva;
	return clonada;

}

void destruir(PilaInt& p) {
	while (!esVacia(p)) {
		pop(p);
	}
	delete p;
}

#endif