#include "MultisetInt.h"

#ifdef MULTISET_INT_IMP

struct _cabezalMultisetInt {
	// NO IMPLEMENTADO
};

MultisetInt crearMultisetInt() {
	// NO IMPLEMENTADO
	return NULL;
}


void agregar(MultisetInt& s, int e, unsigned int ocurrencias){
	// NO IMPLEMENTADO
}

void borrar(MultisetInt& s, int e) {
	// NO IMPLEMENTADO
}

bool pertenece(MultisetInt s, int e) {
	// NO IMPLEMENTADO
	return false;
}

MultisetInt unionConjuntos(MultisetInt s1, MultisetInt s2) {
	// NO IMPLEMENTADO
	return NULL;
}

MultisetInt interseccionConjuntos(MultisetInt s1, MultisetInt s2) {
	// NO IMPLEMENTADO
	return NULL;
}

MultisetInt diferenciaConjuntos(MultisetInt s1, MultisetInt s2) {
	// NO IMPLEMENTADO
	return NULL;
}

bool contenidoEn(MultisetInt s1, MultisetInt s2) {
	// NO IMPLEMENTADO
	return false;
}

int elemento(MultisetInt s) {
	// NO IMPLEMENTADO
	return 0;
}

bool esVacio(MultisetInt s) {
	// NO IMPLEMENTADO
	return true;
}

unsigned int cantidadElementos(MultisetInt s) {
	// NO IMPLEMENTADO
	return 0;
}

void destruir(MultisetInt& s) {
}

MultisetInt clon(MultisetInt s) {
	// NO IMPLEMENTADO
	return NULL;
}

#endif