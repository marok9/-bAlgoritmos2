#include "ListaPosInt.h"

#ifdef LISTA_POS_INT_IMP

struct _cabezalListaPosInt {
	//IMPLEMENTAR SOLUCION
	int largo;			// largo del array
	int cantElementos;	// cantidad de elementos
	int* array;			// array para recorrer las posiciones

};

ListaPosInt crearListaPosInt()
{
	ListaPosInt l = new _cabezalListaPosInt;
	l->largo = 20;
	l->cantElementos = 0;
	l->array = new int[l->largo];
	return l;
}

void agregar(ListaPosInt& l, int e, unsigned int pos)
{
	if (l->cantElementos == l->largo) {
		// hay que duplicar el largo del array.
		int* array = new int[l->largo];
		for (int i = 0; i < l->largo; i++) {
			array[i] = l->array[i];
		}
		delete[] l->array;
		l->largo = l->largo * 2;
		l->array = array;
	}

	if (pos > l->cantElementos) {
		pos = l->cantElementos;
		l->array[l->cantElementos] = e;
	}
	else if (pos < l->cantElementos) {
		for (int i = l->largo - 1; i > pos; i--) {
			l->array[i] = l->array[i - 1];
		}
		l->array[pos] = e;
	}
	else {
		l->array[l->cantElementos] = e;
	}

	l->cantElementos++;

}

void borrar(ListaPosInt& l, unsigned int pos)
{
	if (!esVacia(l)) {
		if (pos < l->largo) {
			for (int i = pos; i < l->largo; i++) {
				l->array[i] = l->array[i + 1];
			}
			l->cantElementos--;
		}
	}
}

int elemento(ListaPosInt l, unsigned int pos)
{
	if (pos >= 0 && pos < l->cantElementos) {
		return l->array[pos];
	}

}

bool esVacia(ListaPosInt l)
{
	return l->cantElementos == 0;
}

unsigned int cantidadElementos(ListaPosInt l)
{
	return l->cantElementos;
}

ListaPosInt clon(ListaPosInt l)
{
	ListaPosInt clonada = crearListaPosInt();
	clonada->array = new int[l->largo];
	clonada->largo = l->largo;
	clonada->cantElementos = l->cantElementos;

	for (int i = 0; i < l->largo; i++) {
		clonada->array[i] = l->array[i];
	}
	return clonada;

}

void destruir(ListaPosInt& l)
{
	delete[] l->array;
	delete l;
}

#endif