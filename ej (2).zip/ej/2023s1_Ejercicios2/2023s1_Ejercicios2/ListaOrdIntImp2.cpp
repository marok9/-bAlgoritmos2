#include "ListaOrdInt.h"

#ifdef LISTA_ORD_INT_IMP_2

struct _cabezalListaOrdInt {
	NodoListaInt* lista;
	int cantidad;
};

ListaOrdInt crearListaOrdInt() {
	ListaOrdInt l = new _cabezalListaOrdInt;
	l->lista = NULL;
	l->cantidad = 0;
	return l;
}

void agregar(ListaOrdInt& l, int e) {
	// se debe agregar de menor a mayor.
	// casos: esta vacia, agregar en la primer posicion, agregar en el meio, agregar al final.

	NodoListaInt* agregar = new NodoListaInt(e); // este es el nodo que hay que agregar.

	// me fijo si esta vacia.
	if (esVacia(l)) {
		// agrego el elemento en la primer posicion.
		l->lista = agregar;
		agregar->sig = NULL;
	}
	else { // no esta vacia

		// me fijo si es menor al primer elemento.
		if (l->lista->dato < e) {
			agregar->sig = l->lista;
			l->lista = agregar;
		}
		else {
			NodoListaInt* punAux = l->lista;
			while (punAux->sig != NULL) {
				if (punAux->sig->dato > e) {
					agregar->sig = punAux->sig;
					punAux->sig = agregar;
				}
				punAux = punAux->sig;
			}
			// chequear ultima posicion.
			if (punAux->dato < e) {
				punAux->sig = agregar;
			}
		}


	}


}

void borrarMinimo(ListaOrdInt& l) {
	NodoListaInt* aBorrar = l->lista;
	l->lista = l->lista->sig;
	delete aBorrar;
	l->cantidad--;
}

void borrarMaximo(ListaOrdInt& l) {
	NodoListaInt* punAux = l->lista;
	while (punAux->sig != NULL) {
		punAux = punAux->sig;
	}
	delete punAux;
}

void borrar(ListaOrdInt& l, int e) {
	// borra el primer elemento que se encuentra igual a e, si no esta, no hay efecto.
	NodoListaInt* punAux = l->lista;
	// me fijo si es en le primer posicion: 
	if (!esVacia(l)) {
		bool borrado = false;
		if (punAux->dato == e) {
			NodoListaInt* aBorrar = punAux;
			punAux = punAux->sig;
			delete aBorrar;
			borrado = true;
		}
		else {
			while (punAux->sig != NULL && !borrado) {
				if (punAux->sig->dato == e) {
					NodoListaInt* aBorrar = punAux->sig;
					punAux->sig = punAux->sig->sig;
					delete aBorrar;
					borrado = true;
				}
				punAux = punAux->sig;
			}
			if (!borrado) {
				if (punAux->dato == e) {
					delete punAux;
				}
			}
		}
	}

}

int minimo(ListaOrdInt l) {
	if (!esVacia(l)) {
		return l->lista->dato;
	}
}

int maximo(ListaOrdInt l) {
	if (!esVacia(l)) {
		NodoListaInt* punAux = l->lista;
		while (punAux->sig != NULL) {
			punAux = punAux->sig;
		}
		return punAux->dato;
	}
}

bool existe(ListaOrdInt l, int e) {
	NodoListaInt* punAux = l->lista;
	while (punAux != NULL) {
		if (punAux->dato == e) {
			return true;
		}
		else {
			punAux = punAux->sig;
		}
	}
	return false;
}

bool esVacia(ListaOrdInt l) {

	return l->cantidad == 0;
}

unsigned int cantidadElementos(ListaOrdInt l) {
	return l->cantidad;
}

ListaOrdInt clon(ListaOrdInt l) {
	ListaOrdInt final = crearListaOrdInt();

	NodoListaInt* lista = NULL;
	NodoListaInt* punFinal = lista;
	NodoListaInt* punAux = l->lista;

	while (punAux != NULL) {
		NodoListaInt* q = new NodoListaInt;
		q->dato = punAux->dato;
		q->sig = NULL;
		if (lista == NULL) {
			lista = q;
			punFinal = lista;
		}
		else {
			punFinal->sig = q;
			punFinal = q;
		}
		punAux = punAux->sig;
	}
	final->lista = lista;
	final->cantidad = l->cantidad;
	return final;
}

void destruir(ListaOrdInt& l) {
	while (!esVacia(l)) {
		borrarMinimo(l);
	}
	delete l;
}



#endif