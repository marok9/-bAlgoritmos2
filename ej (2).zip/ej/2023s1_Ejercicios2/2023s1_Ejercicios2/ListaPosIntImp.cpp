#include "ListaPosInt.h"

#ifdef LISTA_POS_INT_IMP

struct _cabezalListaPosInt {
	//IMPLEMENTAR SOLUCION
	int largo;			// largo del array
	int cantElementos;	// cantidad de elementos
	int* array;			// array para recorrer las posiciones

};

ListaPosInt crearListaPosInt()
{
	ListaPosInt l = new _cabezalListaPosInt;
	l->largo = 20;
	l->cantElementos = 0;
	l->array = new int[l->largo];

	return l;
}

void agregar(ListaPosInt& l, int e, unsigned int pos)
{
	//  POS: Agrega el elemento e en la posicion pos de la lista haciendo que los elementos 
	//  en esa y siguientes posiciones avancen una posicion.
	//  El primer elemento se encuentra en la posicion 0.
	//  Si pos es mayor o igual al largo de la lista insertar al final
	
	

	if (l->largo == l->cantElementos) {
		int* nuevoArray = new int[l->largo * 2];
		for (int i = 0; i < l->largo * 2; i++) {
			nuevoArray[i] = l->array[i];
		}
		delete l->array;
		l->array = nuevoArray;
		l->largo = l->largo * 2;
	}


	for (int i = l->largo - 1; i > pos; i--) {
			l->array[i] = l->array[i - 1];
	}
	l->array[pos] = e;
	
	if (pos >= l->largo) {
		l->array[l->largo - 1] = e;
	}
	l->cantElementos++;
}

void borrar(ListaPosInt& l, unsigned int pos)
{
	//   POS: Borra el elemento en la posicion pos de la lista haciendo que los elementos 
	//   en las siguientes posiciones retrocedan una posicion.
	//	 El primer elemento se encuentra en la posicion 0.
	//   Si pos es mayor o igual al largo de la lista la operacion no tiene efecto
	if (!esVacia(l)) {
		if (pos < l->largo) {
			for (int i = pos; i < l->largo; i++) {
				l->array[i] = l->array[i + 1];
			}
			l->cantElementos--;
		}
	}
	

}

int elemento(ListaPosInt l, unsigned int pos)
{
	// PRE: 0 <= pos < CantidadElementos()
	// POS: Retorna el elemento en la posicion pos
	// El primer elemento se encuentra en la posicion 0.

	if (pos >= 0 && pos < l->cantElementos) {
		return l->array[pos];
	}

}

bool esVacia(ListaPosInt l)
{
	return l->cantElementos == 0;
}

unsigned int cantidadElementos(ListaPosInt l)
{
	return l->cantElementos;
}

ListaPosInt clon(ListaPosInt l)
{
	ListaPosInt clonada = crearListaPosInt();
	int* nuevoArray = new int[l->largo];
	clonada->largo = l->largo;
	clonada->cantElementos = l->cantElementos;
	int* arrayViejo = l->array;
	for (int i = 0; i < l->largo; i++) {
		nuevoArray[i] = arrayViejo[i];
	}
	clonada->array = nuevoArray;
	return clonada;
}

void destruir(ListaPosInt& l)
{
	while (!esVacia(l)) {
		borrar(l, 0);
	}
	delete l;
}


#endif