#pragma once

enum _retorno
{
	OK, ERROR, NO_IMPLEMENTADA, COMENTADA
};
typedef enum _retorno TipoRetorno;
