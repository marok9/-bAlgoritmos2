#pragma once

#include "Prueba.h"
#include "FuncAux.h"
#include "ColaPrioridadInt.h"

// PRE: 
// POS: Inicia el testeo del TAD
void pruebasColaPrioridadInt(Prueba* pruebaConcreta);
