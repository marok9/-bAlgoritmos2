#pragma once

#ifdef SET_INT_IMP

#include <iostream>
using namespace std;
#include <assert.h>

#endif
