#include "ColaInt.h"

#ifdef COLA_INT_IMP

struct _cabezalColaInt {
	// NO IMPLEMENTADO
};

ColaInt crearColaInt() {
	// NO IMPLEMENTADO
	return NULL;
}

void encolar(ColaInt& c, int e) {
	// NO IMPLEMENTADO
}

int principio(ColaInt c) {
	// NO IMPLEMENTADO
	return 0;
}

void desencolar(ColaInt& c) {
	// NO IMPLEMENTADO
}

bool esVacia(ColaInt c) {
	// NO IMPLEMENTADO
	return true;
}

unsigned int cantidadElementos(ColaInt c) {
	// NO IMPLEMENTADO
	return 0;
}

ColaInt clon(ColaInt c) {
	// NO IMPLEMENTADO
	return NULL;
}

void destruir(ColaInt& c) {
	// NO IMPLEMENTADO
}

#endif