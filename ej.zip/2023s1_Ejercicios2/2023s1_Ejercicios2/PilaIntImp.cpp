#include "PilaInt.h"

#ifdef PILA_INT_IMP

struct _cabezalPilaInt {
	// NO IMPLEMENTADO
};


PilaInt crearPilaInt(){
	// NO IMPLEMENTADO
	return NULL;
}

void push(PilaInt& p, int e) {
	// NO IMPLEMENTADO
}

int top(PilaInt p) {
	// NO IMPLEMENTADO
	return 0;
}

void pop(PilaInt& p) {
	// NO IMPLEMENTADO
}

unsigned int cantidadElementos(PilaInt p) {
	// NO IMPLEMENTADO
	return 0;
}

bool esVacia(PilaInt p) {
	// NO IMPLEMENTADO
	return true;
}

PilaInt clon(PilaInt p) {
	// NO IMPLEMENTADO
	return NULL;
}

void destruir(PilaInt& p) {
	// NO IMPLEMENTADO
}


#endif