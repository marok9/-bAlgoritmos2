#include "DiccionarioInt.h"

#ifdef DICCIONARIO_INT_IMP

struct _cabezalDiccionarioInt {
	// NO IMPLEMENTADO
};


DiccionarioInt crearDiccionarioInt(unsigned int esperados) {
	// NO IMPLEMENTADO
	return NULL;
}

void agregar(DiccionarioInt& d, int e) {
	// NO IMPLEMENTADO
}

void borrar(DiccionarioInt& d, int e) {
	// NO IMPLEMENTADO
}

bool pertenece(DiccionarioInt d, int e) {
	// NO IMPLEMENTADO
	return false;
}

int elemento(DiccionarioInt d) {
	// NO IMPLEMENTADO
	return 0;
}

bool esVacio(DiccionarioInt d) {
	// NO IMPLEMENTADO
	return true;
}

unsigned int cantidadElementos(DiccionarioInt d) {
	// NO IMPLEMENTADO
	return 0;
}

DiccionarioInt clon(DiccionarioInt d) {
	// NO IMPLEMENTADO
	return NULL;
}

void destruir(DiccionarioInt& d) {
	// NO IMPLEMENTADO
}


#endif