#include "ListaPosInt.h"

#ifdef LISTA_POS_INT_IMP

struct _cabezalListaPosInt {
	//IMPLEMENTAR SOLUCION
	int largo;			// largo del array
	int cantElementos;	// cantidad de elementos
	int* array;			// array para recorrer las posiciones

};

ListaPosInt crearListaPosInt()
{
	ListaPosInt l = new _cabezalListaPosInt;
	l->largo = 20;
	l->cantElementos = 0;
	l->array = new int[l->largo];

	return l;
}

void agregar(ListaPosInt& l, int e, unsigned int pos)
{

	//IMPLEMENTAR SOLUCION
	// si el largo es igual a cantidad de elementos, duplico el largo del array.

	if (l->largo == l->cantElementos) {
		int* nuevoArray = new int[l->largo * 2];
		for (int i = 0; i < l->largo * 2; i++) {
			nuevoArray[i] = l->array[i];
		}
		l->array = nuevoArray;
		l->largo = l->largo * 2;
	}


}

void borrar(ListaPosInt& l, unsigned int pos)
{
	//IMPLEMENTAR SOLUCION
}

int elemento(ListaPosInt l, unsigned int pos)
{
	//IMPLEMENTAR SOLUCION
	return 0;
}

bool esVacia(ListaPosInt l)
{
	//IMPLEMENTAR SOLUCION
	return true;
}

unsigned int cantidadElementos(ListaPosInt l)
{
	//IMPLEMENTAR SOLUCION
	return 0;
}

ListaPosInt clon(ListaPosInt l)
{
	//IMPLEMENTAR SOLUCION
	return NULL;
}

void destruir(ListaPosInt& l)
{
	//IMPLEMENTAR SOLUCION
}


#endif